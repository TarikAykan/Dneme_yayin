from flask import Flask, render_template, request, redirect, url_for, session
import sqlite3

from datetime import datetime, timedelta

def calculate_total_sessions_and_fee(start_date, end_date, days, fees_per_day):
    start_date = datetime.strptime(start_date, '%Y-%m-%d')
    end_date = datetime.strptime(end_date, '%Y-%m-%d')
    
    total_sessions = 0
    total_fee = 0
    date = start_date
    while date <= end_date:
        day_name = date.strftime('%A')
        if day_name in days:
            total_sessions += 1
            total_fee += fees_per_day[day_name]
        date += timedelta(days=1)
    
    return total_sessions, total_fee

def create_database():
    conn = sqlite3.connect('students.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS students
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                 student_name TEXT NOT NULL,
                 student_surname TEXT NOT NULL,
                 gender TEXT NOT NULL,
                 student_phone TEXT NOT NULL,
                 parent_name TEXT NOT NULL,
                 parent_surname TEXT NOT NULL,
                 parent_phone TEXT NOT NULL,
                 parent_email TEXT NOT NULL)''')
    conn.commit()
    conn.close()
    

def add_student(student_name, student_surname, gender, student_phone, parent_name, parent_surname, parent_phone, parent_email):
    conn = sqlite3.connect('students.db')
    c = conn.cursor()
    c.execute("INSERT INTO students (student_name, student_surname, gender, student_phone, parent_name, parent_surname, parent_phone, parent_email) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
              (student_name, student_surname, gender, student_phone, parent_name, parent_surname, parent_phone, parent_email))
    conn.commit()
    conn.close()

def create_services_table():
    conn = sqlite3.connect('students.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS services
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                 student_id INTEGER NOT NULL,
                 table_number INTEGER NOT NULL,
                 days TEXT NOT NULL,
                 time_slot TEXT NOT NULL,
                 FOREIGN KEY (student_id) REFERENCES students (id))''')
    conn.commit()
    conn.close()

def add_service(student_id, table_number, days, time_slots):
    conn = sqlite3.connect('students.db')
    c = conn.cursor()
    days_str = ','.join(days)
    time_slots_str = ','.join([f'{day}:{time_slot}' for day, time_slot in time_slots.items()])
    c.execute("INSERT INTO services (student_id, table_number, days, time_slot) VALUES (?, ?, ?, ?)",
              (student_id, table_number, days_str, time_slots_str))
    conn.commit()
    conn.close()

def get_all_students():
    conn = sqlite3.connect('students.db')
    c = conn.cursor()
    c.execute("SELECT * FROM students")
    students = c.fetchall()
    conn.close()
    return students

def create_sales_table():
    conn = sqlite3.connect('students.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS sales
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                 student_id INTEGER NOT NULL,
                 service_id INTEGER NOT NULL,
                 start_date TEXT NOT NULL,
                 end_date TEXT NOT NULL,
                 total_sessions INTEGER NOT NULL,
                 total_fee REAL NOT NULL,
                 FOREIGN KEY (student_id) REFERENCES students (id),
                 FOREIGN KEY (service_id) REFERENCES services (id))''')
    conn.commit()
    conn.close()

def add_sale(student_id, service_id, start_date, end_date, total_sessions, total_fee):
    conn = sqlite3.connect('students.db')
    c = conn.cursor()
    c.execute("INSERT INTO sales (student_id, service_id, start_date, end_date, total_sessions, total_fee) VALUES (?, ?, ?, ?, ?, ?)",
              (student_id, service_id, start_date, end_date, total_sessions, total_fee))
    conn.commit()
    sale_id = c.lastrowid
    conn.close()
    return sale_id

def get_student_sales(student_id):
    conn = sqlite3.connect('students.db')
    c = conn.cursor()
    c.execute("SELECT * FROM sales WHERE student_id=?", (student_id,))
    sales = c.fetchall()
    conn.close()
    return sales

def get_student(student_id):
    conn = sqlite3.connect('students.db')
    c = conn.cursor()
    c.execute("SELECT * FROM students WHERE id=?", (student_id,))
    student = c.fetchone()
    conn.close()
    return student

create_services_table()
create_database()
create_sales_table()

app = Flask(__name__)
app.secret_key = 'your_secret_key'

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        if username == 'admin' and password == 'password':
            session['username'] = username
            return redirect(url_for('index'))
        else:
            return 'Hatalı kullanıcı adı veya şifre. Lütfen tekrar deneyin.'

    return render_template('login.html')

@app.route('/registered_students', methods=['GET'])
def registered_students():
    students = get_all_students()
    student_sales = {student[0]: get_student_sales(student[0]) for student in students}
    return render_template('registered_students.html', students=students, student_sales=student_sales)

@app.route('/register', methods=['GET', 'POST'])
def register():
    message = ""
    if request.method == 'POST':
        student_name = request.form['student_name']
        student_surname = request.form['student_surname']
        gender = request.form['gender']
        student_phone = request.form['student_phone']
        parent_name = request.form['parent_name']
        parent_surname = request.form['parent_surname']
        parent_phone = request.form['parent_phone']
        parent_email = request.form['parent_email']
        add_student(student_name, student_surname, gender, student_phone, parent_name, parent_surname, parent_phone, parent_email)
        message = 'Öğrenci başarıyla kaydedildi.'

    return render_template('register.html', message=message)

@app.route('/service_sale', methods=['GET', 'POST'])
def service_sale():
    message = ""
    students = get_all_students()
    total_sessions = None
    total_fee = None
    if request.method == 'POST':
        student_id = request.form['student_id']
        table_number = request.form['table_number']
        days = request.form.getlist('days[]')
        time_slots = {day: request.form[f'{day}_time_slot'] for day in days}
        start_date = request.form['start_date']
        end_date = request.form['end_date']
        fees_per_day = {day: float(request.form[f'{day}_fee']) for day in days }
        total_sessions, total_fee = calculate_total_sessions_and_fee(start_date, end_date, days, fees_per_day)

        add_service(student_id, table_number, days, time_slots)
        message = 'Hizmet başarıyla satıldı.'

    return render_template('service_sale.html', message=message, students=students, total_sessions=total_sessions, total_fee=total_fee)

@app.route('/logout', methods=['GET'])
def logout():
    session.pop('username', None)
    return redirect(url_for('index'))

@app.route('/student_report/<int:student_id>', methods=['GET'])
def student_report(student_id):
    student = get_student(student_id)
    student_sales = get_student_sales(student_id)
    return render_template('student_report.html', student=student, student_sales=student_sales)

def get_students_with_services():
    conn = sqlite3.connect('students.db')
    conn.row_factory = sqlite3.Row  # Bu satırı ekleyin
    c = conn.cursor()
    c.execute("SELECT * FROM students WHERE id IN (SELECT DISTINCT student_id FROM sales)")
    students = c.fetchall()
    conn.close()
    return students


@app.route('/students_with_services')
def students_with_services():
    students = get_students_with_services()
    return render_template('students_with_services.html', students=students)

@app.route('/student_profile/<int:student_id>', methods=['GET'])
def student_profile(student_id):
    student = get_student(student_id)
    sales = get_student_sales(student_id)
    student = {
        'id': student[0],
        'student_name': student[1],
        'student_surname': student[2],
        'gender': student[3],
        'student_phone': student[4],
        'parent_name': student[5],
        'parent_surname': student[6],
        'parent_phone': student[7],
        'parent_email': student[8],
    }
    return render_template('student_profile.html', student=student, sales=sales)

if __name__ == '__main__':
    app.run(debug=True)